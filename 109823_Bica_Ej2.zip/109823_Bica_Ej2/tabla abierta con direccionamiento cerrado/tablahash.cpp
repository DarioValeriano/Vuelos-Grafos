#include <iostream>
#include <sstream>
#include "tablahash.h"
#include "lista.h"

Tabla_hash::Tabla_hash(){
    tabla_hash = new Lista[67]; // Array de punteros a Aeropuerto
}

void Tabla_hash::consulta(string ciudad){
    cout<<ciudad;
    int clave = hashear(ciudad);
    int posicion = buscar(ciudad,clave);
    if(posicion != 0){
        Aeropuerto* aeropuerto (tabla_hash[clave].consulta(posicion));
        cout <<"CodigoIATA: " <<aeropuerto->getCodigoIATA() << endl;
 /*       cout <<"Nombre: " <<aeropuerto->getNombre() << endl;
        cout <<"Ciudad: " <<aeropuerto->getCiudad() << endl;
        cout <<"Pais: " <<aeropuerto->getPais() << endl;
        cout <<"Superficie: " <<aeropuerto->getSuperficie() << endl;
        cout <<"CantidadTerminales: " <<aeropuerto->getCantidadTerminales() << endl;
        cout <<"DestinosNacionales: " <<aeropuerto->getDestinosNacionales() << endl;
       cout <<"DestinosInternacionales: " <<aeropuerto->getDestinosInternacionales() << endl; 
 */   }
    else{
        cout<<"ciudad no encontrada"<<endl;
    }
}

void Tabla_hash::cargar_archivo_aeropuertos(string nombreArchivo){
    ifstream archivo(nombreArchivo);
    string linea;

    while (getline(archivo, linea)) {

        istringstream iss(linea);
        string codigoIATA, aeropuerto, nombreCiudad, pais;
        double superficie;
        int cantidadTerminales, destinosNacionales, destinosInternacionales;
        iss >> codigoIATA >> aeropuerto>> nombreCiudad >> pais >> superficie >> cantidadTerminales >> destinosNacionales >> destinosInternacionales;
        Aeropuerto aeropuertoN(codigoIATA,aeropuerto,nombreCiudad,pais,superficie,cantidadTerminales, destinosNacionales, destinosInternacionales);
        guardar(aeropuertoN);
        
    }   
    archivo.close();
}

int Tabla_hash::hashear(string ciudad){
    int hash = 0;
    for (char c : ciudad) {
        int ascii = static_cast<int>(c);
        hash += ascii * (128 - ascii);
        }
    if(hash >=67){
            hash = hash%67;
    }
    return hash;
}

int Tabla_hash::buscar(string ciudad, int clave) {
    int posicion = 0;
    bool posicion_valida = true;
    if(!tabla_hash[clave].esta_vacia()){
    posicion++;}
    if(posicion == 1){
    while(tabla_hash[clave].consulta(posicion)->getCiudad() != ciudad && posicion_valida ){
        posicion++;
        if(tabla_hash[clave].consulta(posicion) == nullptr){
            posicion_valida = false;
            posicion = 0;
        }
    }}
    return posicion;
}


void Tabla_hash::guardar(Aeropuerto aeropuerton) {
    int clave = hashear(aeropuerton.getCiudad());
    int i = 1;

    tabla_hash[clave].alta(new Aeropuerto(aeropuerton), i);
}

void Tabla_hash::eliminar(string ciudad){
    Aeropuerto aeropuerto_vacio;
    int clave = hashear(ciudad);
    int posicion = 1;
    while(tabla_hash[clave].consulta(posicion)->getCiudad() != ciudad){
        posicion++;
    }
    tabla_hash[clave].baja(posicion);
}

Tabla_hash::~Tabla_hash() {
    for (int i = 0; i < 67; ++i) {
    }
}