#ifndef TABLAHASH_H
#define TABLAHASH_H

#include <fstream>
#include "aeropuerto.h"
#include "lista.h"
#include <string>

using namespace std;

class Tabla_hash{
private:
    Lista* tabla_hash;
public:
    Tabla_hash();


    /* Precondición: La cadena 'ciudad' es válida y no está vacía
       Postcondición: Devuelve el valor hash para la ciudad dada */
    int hashear(string ciudad);

    /* Pre: El archivo 'nombreArchivo' es válido y existe
       Post: Carga los datos de los aeropuertos desde el archivo dado */
    void cargar_archivo_aeropuertos(string nombreArchivo);

    /* Pre: La cadena 'ciudad' es válida y no está vacía
       Post: Busca la ciudad dada en la tabla hash y devuelve su posición en la lista */
    int buscar(string ciudad, int clave);

    /* Pre: La cadena 'ciudad' es válida y no está vacía
       Post: Imprime la información del aeropuerto correspondiente a la ciudad dada */
    void consulta(string ciudad);

    /* Pre: El objeto 'aeropuerto' es válido y contiene información válida
       Post: Guarda el aeropuerto en la tabla hash */
    void guardar(Aeropuerto aeropuerto);

    /* Pre: La cadena 'ciudad' es válida y no está vacía
       Post: Elimina el aeropuerto correspondiente a la ciudad dada de la tabla hash */
    void eliminar(string ciudad);

    /* Pre: -
       Post: Destruye un objeto Tabla_hash */
    ~Tabla_hash();
};
#endif //TABLAHASH_H