#ifndef AEROPUERTO_H
#define AEROPUERTO_H

#include <string>

using namespace std;

class Aeropuerto {
private:
    string codigo_IATA;
    string nombre;
    string ciudad;
    string pais;
    double superficie;
    int cantidad_terminales;
    int destinos_nacionales;
    int destinos_internacionales;

public:
    // Constructor
    Aeropuerto(string codigo_iata, string nombre, string ciudad, string pais, double superficie, int cantidad_terminales,int destinos_nacionales,int destinos_internacionales);
    Aeropuerto();
    
    //metodos
    /* Pre: -
       Post: Devuelve el código IATA del aeropuerto */
    std::string getCodigoIATA() const;

    /* Pre: -
       Post: Devuelve el nombre del aeropuerto */
    std::string getNombre() const;

    /* Pre: -
       Postcondición: Devuelve el nombre de la ciudad del aeropuerto */
    std::string getCiudad() const;
    
    /* Pre: -
       Postcondición: Devuelve el nombre del país del aeropuerto */
    std::string getPais() const;
    
    /* Pre: -
       Postcondición: Devuelve la superficie del aeropuerto en metros cuadrados */
    double getSuperficie() const;
    
    /* Pre: -
       Postcondición: Devuelve la cantidad de terminales del aeropuerto */
    int getCantidadTerminales() const;
    
    /* Pre: -
       Postcondición: Devuelve la cantidad de destinos nacionales del aeropuerto */
    int getDestinosNacionales() const;
    
    /* Pre: -
       Postcondición: Devuelve la cantidad de destinos internacionales del aeropuerto */
    int getDestinosInternacionales() const;

};

#endif /* AEROPUERTO_H */
