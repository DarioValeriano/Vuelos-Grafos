#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "tablahash.h"

using namespace std;

int main() {
    string nombreArchivo = "aeropuertos.txt";
    Tabla_hash nueva_tabla;
    nueva_tabla.cargar_archivo_aeropuertos(nombreArchivo);
    int opcion;
    string codigoIATA;
    string ciudad;
    string aeropuerto;
    string pais;
    float superficie;
    int cantidadTerminales;
    int destinosNacionales;
    int destinosInternacionales;
    Aeropuerto aeropuerto_nuevo(codigoIATA,aeropuerto,ciudad,pais,superficie,cantidadTerminales, destinosNacionales, destinosInternacionales);


    cout <<"Seleccione una opcion"<<endl;
    cout <<"1) consulta"<<endl;
    cout <<"2) alta"<<endl;
    cout <<"3) baja"<<endl;
    cout <<"4) salir"<<endl;
    cin >> opcion;
    switch (opcion)
    {
    case 1:
        cout<<"Ingrese el nombre de la ciudad a consultar: "<<endl;
        cin >> ciudad;
        nueva_tabla.consulta(ciudad);
        break;
    case 2:
        cout<<"Ingrese los datos del aeropuerto a dar de alta "<<endl;
        
        cout<<"codigoIATA: ";
        cin>>codigoIATA;
        cout<<"nombre del aeropuerto: ";
        cin>>aeropuerto;
        cout<<"ciudad: ";
        cin>>ciudad;
        cout<<"pais: ";
        cin>>pais;
        cout<<"superficie: ";
        cin>>superficie;
        cout<<"cantidadTerminales: ";
        cin>>cantidadTerminales;
        cout<<"destinosNacionales: ";
        cin>>destinosNacionales;
        cout<<"destinosInternacionales: ";
        cin>>destinosInternacionales;
        nueva_tabla.guardar(aeropuerto_nuevo);
        cout<<"Se ha agregado el aeropuerto"; 
        break;
    case 3:
        cout<<"Ingrese el nombre de la ciudad del aeropuerto a dar de baja: "<<endl;
        cin >> ciudad;
        nueva_tabla.eliminar(ciudad);
        cout<<"Se ha eliminado el aeropuerto";  
        break;
    }
    return 0;
}
