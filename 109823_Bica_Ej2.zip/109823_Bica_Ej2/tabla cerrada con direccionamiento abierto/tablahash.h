#ifndef TABLAHASH_H
#define TABLAHASH_H

#include <fstream>
#include "aeropuerto.h"
#include <string>

using namespace std;

class Tabla_hash{
private:
    Aeropuerto** tabla_hash;
public:
    //constructor
    Tabla_hash();

    //metodos
    // Pre: -
    // Postcondición: Devuelve un valor entero que representa la posición calculada para la ciudad dada.
    int hashear(string ciudad);

    // Pre:-
    // Post: Los datos de los aeropuertos se cargan en la tabla hash.
    void cargar_archivo_aeropuertos(string nombreArchivo);

    // Pre: -
    // Post: Si se encuentra la ciudad en la tabla hash, devuelve la posición donde se encuentra, sino devuelve 67
    int buscar(string ciudad);

    // Pre: -
    // Post: Imprime la información del aeropuerto correspondiente a la ciudad dada.
    void consulta(string ciudad);

    // Pre: -
    // Post: Devuelve verdadero si la posición de la tabla hash correspondiente a la clave está vacía, de lo contrario, falso.
    bool posicion_vacia(int clave);

    // Pre: -
    // Post: Guarda el aeropuerto dado en la tabla hash, utilizando direccionamiento abierto en caso de colisión.
    void guardar(Aeropuerto aeropuerto);

    // Pre: la ciudad existe en la tabla hash.
    // Post: Elimina el aeropuerto correspondiente a la ciudad dada de la tabla hash.
    void eliminar(string ciudad);

    //destructor
    ~Tabla_hash();
};
#endif //TABLAHASH_H