#include <iostream>
#include <sstream>
#include "tablahash.h"

const int TAMANIO_TABLA = 67;

Tabla_hash::Tabla_hash(){
    tabla_hash = new Aeropuerto*[TAMANIO_TABLA]; // Array de punteros a Aeropuerto
    for(int i = 0; i < TAMANIO_TABLA; ++i) {
        tabla_hash[i] = nullptr; // Inicializar todos los punteros a nullptr
    }
}



void Tabla_hash::consulta(string ciudad){
    int clave = buscar(ciudad);
    if(clave < TAMANIO_TABLA){
    Aeropuerto* aeropuerto (tabla_hash[clave]);
    cout <<"CodigoIATA: " <<aeropuerto->getCodigoIATA() << endl;
/*    cout <<"Nombre: " <<aeropuerto->getNombre() << endl;
    cout <<"Ciudad: " <<aeropuerto->getCiudad() << endl;
    cout <<"Pais: " <<aeropuerto->getPais() << endl;
    cout <<"Superficie: " <<aeropuerto->getSuperficie() << endl;
    cout <<"CantidadTerminales: " <<aeropuerto->getCantidadTerminales() << endl;
    cout <<"DestinosNacionales: " <<aeropuerto->getDestinosNacionales() << endl;
    cout <<"DestinosInternacionales: " <<aeropuerto->getDestinosInternacionales() << endl; 
*/    }
    else{
        cout<<"Ciudad no encontrada"<<endl;
    }
}

void Tabla_hash::cargar_archivo_aeropuertos(string nombreArchivo){
    ifstream archivo(nombreArchivo);
    string linea;
    while (getline(archivo, linea)) {

        istringstream iss(linea);
        string codigoIATA, aeropuerto, nombreCiudad, pais;
        double superficie;
        int cantidadTerminales, destinosNacionales, destinosInternacionales;
        iss >> codigoIATA >> aeropuerto>> nombreCiudad >> pais >> superficie >> cantidadTerminales >> destinosNacionales >> destinosInternacionales;
        Aeropuerto aeropuertoN(codigoIATA,aeropuerto,nombreCiudad,pais,superficie,cantidadTerminales, destinosNacionales, destinosInternacionales);
        guardar(aeropuertoN);
    }   
    archivo.close();
}

int Tabla_hash::hashear(string ciudad){
    int hash = 0;
    for (char c : ciudad) {
        int ascii = static_cast<int>(c);
        hash += ascii * (128 - ascii);
        }
    if(hash >=TAMANIO_TABLA){
            hash = hash%TAMANIO_TABLA;
    }
    return hash;
}


int Tabla_hash::buscar(string ciudad) {
    int clave = hashear(ciudad);
    Aeropuerto* valor = tabla_hash[clave];
    int i = 1;
    while (valor != nullptr && valor->getCiudad() != ciudad && i <= 66) {
        clave = (clave + 1) % TAMANIO_TABLA; 
        valor = tabla_hash[clave];
        i++;
    }
    if (valor == nullptr || valor->getCiudad() != ciudad) {
        clave = TAMANIO_TABLA; 
    }
    return clave;
}

bool Tabla_hash::posicion_vacia(int clave){
    Aeropuerto* aeropuerto_actual = tabla_hash[clave];
    return tabla_hash[clave] == nullptr || aeropuerto_actual->getCiudad().empty();
}

void Tabla_hash::guardar(Aeropuerto aeropuerton){
    int clave = hashear(aeropuerton.getCiudad());
    if (!posicion_vacia(clave)){
        int i = 1;
        bool posicion_encontrada = false;
        while(i<=TAMANIO_TABLA && !posicion_encontrada){
            if(clave < 66){
                clave += 1;
            }
            else{
                clave = 0;
            }
            i++;
            if(posicion_vacia(clave)){
                posicion_encontrada = true;
            }
        }
    }
    tabla_hash[clave] = new Aeropuerto(aeropuerton);
}

void Tabla_hash::eliminar(string ciudad){
    Aeropuerto aeropuerto_vacio;
    int clave = buscar(ciudad);
    delete tabla_hash[clave];
    tabla_hash[clave]= new Aeropuerto(aeropuerto_vacio);
}

Tabla_hash::~Tabla_hash() {
    for (int i = 0; i < TAMANIO_TABLA; ++i) {
        delete tabla_hash[i]; 
    }
    delete[] tabla_hash; 
}