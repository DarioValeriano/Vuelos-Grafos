#include "aeropuerto.h"
                                                                                         
// Constructores
Aeropuerto::Aeropuerto(string codigo_iata, string nombre, string ciudad, string pais, double superficie, int cantidad_terminales,int destinos_nacionales,int destinos_internacionales)
    : codigo_IATA(codigo_iata), nombre(nombre), ciudad(ciudad), pais(pais), superficie(superficie), cantidad_terminales(cantidad_terminales),  destinos_nacionales( destinos_nacionales), destinos_internacionales (destinos_internacionales){}

Aeropuerto::Aeropuerto(){
    ciudad = "";
}

// Metodos
string Aeropuerto::getCodigoIATA() const {
    return codigo_IATA;
}

string Aeropuerto::getNombre() const {
    return nombre;
}

string Aeropuerto::getCiudad() const {
    return ciudad;
}

string Aeropuerto::getPais() const {
    return pais;
}

double Aeropuerto::getSuperficie() const {
    return superficie;
}

int Aeropuerto::getCantidadTerminales() const {
    return cantidad_terminales;
}

int Aeropuerto::getDestinosNacionales() const {
    return destinos_nacionales;
}

int Aeropuerto::getDestinosInternacionales() const {
    return destinos_internacionales;
}