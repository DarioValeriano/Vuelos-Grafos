//
// Created by luzacu on 20/02/24.
//

#ifndef UNTITLED3_AEROPUERTO_H
#define UNTITLED3_AEROPUERTO_H
#include <iostream>
#include <fstream>

using namespace std;
const int FILAS = 3;
const int COLUMNAS = 2;

class Aeropuerto{
private:
    string** ciudad_codigo;
    int filas;
    int columnas;
    string codigo_iata;
    string nombre;
    string ciudad;
    string pais;
    double superficie;
    int cant_terminales;
    int destinos_internacionales;
    int destinos_nacionales;

public:
    Aeropuerto(string codigo_iata, string nombre, string ciudad, string pais, double superficie, int cant_terminales, int destinos_internacionales, int destinos_nacionales);

    Aeropuerto();

    ~Aeropuerto();

    string obtener_codigo_aeropuerto(string ciudad);

    string** obtener_matriz();

    void imprimir_matriz();

    void redimensionar_matriz(int fila);

    void achicar_matriz(int fila);
};

#endif //UNTITLED3_AEROPUERTO_H
