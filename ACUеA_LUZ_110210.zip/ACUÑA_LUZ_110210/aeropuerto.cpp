//
// Created by luzacu on 20/02/24.
//
#include "aeropuerto.h"

Aeropuerto::Aeropuerto(string codigo_iata, string nombre, string ciudad, string pais, double superficie, int cant_terminales, int destinos_internacionales, int destinos_nacionales){
    this -> codigo_iata = codigo_iata;
    this -> nombre = nombre;
    this -> ciudad = ciudad;
    this -> pais = pais;
    this -> superficie = superficie;
    this -> cant_terminales = cant_terminales;
    this -> destinos_internacionales = destinos_internacionales;
    this -> destinos_nacionales = destinos_nacionales;

}

Aeropuerto::Aeropuerto() {
    filas = FILAS;
    columnas = COLUMNAS;
    ciudad_codigo = new std::string*[filas];
    for (int i = 0; i < filas; i++) {
        ciudad_codigo[i] = new string[columnas];
    }
}

void Aeropuerto::redimensionar_matriz(int fila){
    if (fila >= filas) {
        string** nueva_ciudad_codigo = new string*[2 * filas];
        for (int i = 0; i < filas; ++i) {
            nueva_ciudad_codigo[i] = ciudad_codigo[i];
        }
        delete[] ciudad_codigo;
        ciudad_codigo = nueva_ciudad_codigo;
        filas *= 2;
    }
}

void Aeropuerto::achicar_matriz(int fila){
    if (fila <= filas) {
        string** nueva_ciudad_codigo = new string*[filas / 2];
        for (int i = 0; i < filas; ++i) {
            nueva_ciudad_codigo[i] = ciudad_codigo[i];
        }
        delete[] ciudad_codigo;
        ciudad_codigo = nueva_ciudad_codigo;
        filas /= 2;
    }
}

string** Aeropuerto::obtener_matriz() {
    ifstream aeropuertos("aeropuertos.txt");

    string codigo_iata, nombre, ciudad, pais;
    double superficie;
    int cantidad_terminales, destinos_nacionales, destinos_internacionales;

    int fila = 0;
    while (aeropuertos >> codigo_iata >> nombre >> ciudad >> pais >> superficie >> cantidad_terminales >> destinos_nacionales >> destinos_internacionales) {
        redimensionar_matriz(fila);
        ciudad_codigo[fila][0] = ciudad;
        ciudad_codigo[fila][1] = codigo_iata;
        fila++;
    }
    aeropuertos.close();
    return ciudad_codigo;
}

void Aeropuerto::imprimir_matriz(){
    string** matriz = obtener_matriz();
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; ++j) {
            cout << " " << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

string Aeropuerto::obtener_codigo_aeropuerto(string ciudad) {
    string** matriz = obtener_matriz();
    string codigo_iata;
    bool encontrado = false;
    int i = 0;
    while(i <= filas && !encontrado) {
        cout << matriz[i][0] << endl;
        if(matriz[i][0] == ciudad){
            codigo_iata = matriz[i][1];
            encontrado = true;
        }
        i++;
    }
    return codigo_iata;
}

Aeropuerto::~Aeropuerto() {
    for (int i = 0; i < filas; i++) {
        delete[] ciudad_codigo[i];
    }
    delete[] ciudad_codigo;
}

