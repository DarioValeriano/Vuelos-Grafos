#ifndef __ABB_H__
#define __ABB_H__

#include <iostream>
#include "Nodo.h"
#include "aeropuerto.h"

using namespace std;

template <class T>
class ABB
{
    private:
        Nodo<T>* raiz;

        //PRE: --
        //POST: Agrega un nodo con la clave y un puntero a datos de un aeropuerto dado al árbol
        void insertar(Nodo<T>* nodo, T clave, Aeropuerto* aeropuerto);

        //PRE: --
        //POST: Elimina el nodo del árbol, mantiene el arbol ordenado
        void eliminar(Nodo<T>* nodo);

        //PRE: --
        //POST: Recorre desde el nodo en postorden
        void post_orden(Nodo<T>* nodo);

        //PRE: --
        //POST: Busca el nodo con el dato dado en el árbol, si no lo encuentra devuelve nullptr
        Nodo<T>* buscar(Nodo<T>* nodo, T clave);

        //PRE: --
        //POST: Devuelve el nodo inmediato predecesor al nodo dado
        Nodo<T>* obtener_inmediato_sucesor(Nodo<T>* nodo);

        //PRE: --
        //POST: Devuelve el nodo inmediato sucesor al nodo dado
        Nodo<T>* obtener_inmediato_predecesor(Nodo<T>* nodo);
    public:

        ABB();

        //PRE: --
        //POST: Agrega el dato al árbol
        void insertar(T clave, Aeropuerto* aeropuerto);

        //PRE: --
        //POST: Elimina el dato del árbol
        void eliminar(T clave);

        void eliminar_linea(string primera_palabra);

        //PRE: --
        //POST: Indica si el dato está en el árbol
        bool esta_en_el_arbol(T clave);

        //PRE: --
        //POST: Recorre el árbol en postorden
        void post_orden();

        void menu();

        void opciones();

        void nuevo_aeropuerto();

        ~ABB();
};

template <class T>
ABB<T>::ABB() {
    raiz = nullptr;
}

template <class T>
ABB<T>::~ABB() {
    delete raiz;
}

template <class T>
void ABB<T>::insertar(T clave, Aeropuerto* aeropuerto) {
    if (raiz == nullptr) {
        raiz = new Nodo<T>(clave, aeropuerto);
    } else if (!esta_en_el_arbol(clave)){ //Se asegura que el elemento no exista para no agregar repetidos.
        insertar(raiz, clave, aeropuerto);
    }
}

template <class T>
void ABB<T>::insertar(Nodo<T>* nodo, T clave, Aeropuerto* aeropuerto) {
    if (clave < nodo->obtener_dato()) {
        if (nodo->obtener_hijo_izquierdo() == nullptr) {
            nodo->asignar_hijo_izquierdo(new Nodo<T>(clave, aeropuerto));
        } else {
            insertar(nodo->obtener_hijo_izquierdo(), clave, aeropuerto);
        }
    } else {
        if (nodo->obtener_hijo_derecho() == nullptr) {
            nodo->asignar_hijo_derecho(new Nodo<T>(clave, aeropuerto));
        } else {
            insertar(nodo->obtener_hijo_derecho(), clave, aeropuerto);
        }
    }
}

template <class T>
bool ABB<T>::esta_en_el_arbol(T clave) {
    return buscar(raiz, clave) != nullptr;
}

template <class T>
Nodo<T>* ABB<T>::buscar(Nodo<T>* nodo, T clave) {
    if (nodo == nullptr){
        return nullptr;
    }
    if (clave == nodo->obtener_dato()){
        return nodo;
    }
    if (clave < nodo->obtener_dato()){
        return buscar(nodo->obtener_hijo_izquierdo(), clave);
    }
    return buscar(nodo->obtener_hijo_derecho(), clave);

}

template <class T>
Nodo<T>* ABB<T>::obtener_inmediato_predecesor(Nodo<T>* nodo) {
    Nodo<T>* predecesor = nodo->obtener_hijo_izquierdo();
    while (predecesor->obtener_hijo_derecho() != nullptr) {
        predecesor = predecesor->obtener_hijo_derecho();
    }
    return predecesor;
}

template <class T>
Nodo<T>* ABB<T>::obtener_inmediato_sucesor(Nodo<T>* nodo) {
    Nodo<T>* sucesor = nodo->obtener_hijo_derecho();
    while (sucesor->obtener_hijo_izquierdo() != nullptr) {
        sucesor = sucesor->obtener_hijo_izquierdo();
    }
    return sucesor;
}

template <class T>
void ABB<T>::eliminar(T clave) {
    if (raiz != nullptr) {
        Nodo<T>* nodo = buscar(raiz, clave);
        if (nodo != nullptr){
            eliminar(nodo);
        }
    }
    eliminar_linea(clave);
}

template <class T>
void ABB<T>::eliminar(Nodo<T>* nodo) {

    if (nodo->obtener_hijo_izquierdo() != nullptr && nodo->obtener_hijo_derecho() != nullptr) {
        Nodo<T>* predecesor = obtener_inmediato_predecesor(nodo);
        nodo->asignar_dato(predecesor->obtener_dato());
        eliminar(predecesor);
    } else if (nodo->obtener_hijo_izquierdo() != nullptr || nodo->obtener_hijo_derecho() != nullptr) {
        if (nodo->obtener_hijo_izquierdo() != nullptr){
            Nodo<T>* predecesor = obtener_inmediato_predecesor(nodo);
            nodo->asignar_dato(predecesor->obtener_dato());
            eliminar(predecesor);
        } else {
            Nodo<T>* sucesor = obtener_inmediato_sucesor(nodo);
            nodo->asignar_dato(sucesor->obtener_dato());
            eliminar(sucesor);
        }
    } else if (nodo == raiz){
        delete raiz;
        raiz = nullptr;
    } else{
        nodo->obtener_padre()->remover_hijo(nodo);
        delete nodo;
    }

}

template <class T>
void ABB<T>::eliminar_linea(string primera_palabra){
    fstream archivo("aeropuertos.txt");

    string linea;

    ofstream archivo_temporal("temp.txt");

    while (getline(archivo, linea)) {
        if (linea.find(primera_palabra) == 0) {
            continue;
        }
        archivo_temporal << linea << std::endl;
    }

    archivo.close();
    archivo_temporal.close();

    remove("aeropuertos.txt");
    rename("temp.txt", "aeropuertos.txt");
}

template <class T>
void ABB<T>::post_orden() {
    post_orden(raiz);
}

template <class T>
void ABB<T>::post_orden(Nodo<T>* nodo) {
    if (nodo != nullptr){
        post_orden(nodo->obtener_hijo_izquierdo());
        post_orden(nodo->obtener_hijo_derecho());
        cout << nodo->obtener_dato() << " ";
    }
}

template <class T>
void ABB<T>::nuevo_aeropuerto(){
    string codigo_iata, nombre, ciudad, pais;
    double superficie;
    int cantidad_terminales, destinos_nacionales, destinos_internacionales;
    cout << "Ingrese el codigo IATA del aeropuerto" << endl;
    cin >> codigo_iata;
    cout << "Ingrese el nombre del aeropuerto" << endl;
    cin >> nombre;
    cout << "Ingrese la ciudad donde esta el aeropuerto" << endl;
    cin >> ciudad;
    cout << "Ingrese el pais donde se encuentra" << endl;
    cin >> pais;
    cout << "Ingrese la superficie en km²" << endl;
    cin >> superficie;
    cout << "Ingrese la cantidad de terminales" << endl;
    cin >> cantidad_terminales;
    cout << "Ingrese la acntidad de destinos nacionales" << endl;
    cin >> destinos_nacionales;
    cout << "Ingrese la cantidad de destinos internacionales" << endl;
    cin >> destinos_internacionales;
    Aeropuerto *aeropuerto;
    aeropuerto = new Aeropuerto(codigo_iata, nombre, ciudad, pais, superficie,
                                cantidad_terminales, destinos_nacionales,
                                destinos_internacionales);
    if (!esta_en_el_arbol(codigo_iata)){
        insertar(codigo_iata, aeropuerto);
    }
    else{
        cout << "El aeropuerto ya existe" << endl;
    }
    ofstream archivo("aeropuertos.txt");
    archivo << codigo_iata << " " << nombre << " " << ciudad << " " << pais << " " << superficie << " " << cantidad_terminales << " " << destinos_nacionales << " " << destinos_internacionales << endl;
    archivo.close();
}

template <class T>
void ABB<T>::menu(){
    cout << "MENÚ:" << endl;
    cout << "1 - Dar de alta un nuevo aeropuerto" << endl;
    cout << "2 - Dar de baja un aeropuerto" << endl;
    cout << "3 - Consultar información del aeropuerto" << endl;
}

template <class T>
void ABB<T>::opciones(){
    int opcion;
    T ciudad;
    menu();
    cout << "Ingrese una opción: " << endl;
    cin >> opcion;
    cout << "Ingrese la ciudad del aeropuerto: " << endl;
    cin >> ciudad;
    Aeropuerto aeropuerto;
    string clave = aeropuerto.obtener_codigo_aeropuerto(ciudad);
    switch (opcion) {
        case 1:
            nuevo_aeropuerto();
            post_orden();
            break;
        case 2:
            if(esta_en_el_arbol(clave)){
                eliminar(clave);
                post_orden();
            }
            else{
                cout << "El aeropuerto que quiere eliminar no existe" << endl;
            }
            break;

        case 3:
            if(esta_en_el_arbol(clave)){
                cout << "El código IATA del aeropuerto de " << ciudad << " es: " << clave;
            }else{
                cout << "El aeropuerto no existe" << endl;
            }
            break;

        default:
            cout << "Opción no válida." << endl;
            break;
    }
}

#endif
