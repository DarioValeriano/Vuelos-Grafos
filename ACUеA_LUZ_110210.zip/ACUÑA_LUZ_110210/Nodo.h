#ifndef __NODO_H__
#define __NODO_H__

#include <iostream>
#include "aeropuerto.h"

template <class T>
class Nodo
{
    private:
        T clave;
        Aeropuerto* aeropuerto;
        Nodo<T>* hijo_izquierdo;
        Nodo<T>* hijo_derecho;
        Nodo<T>* padre;
    public:
        Nodo(T clave, Aeropuerto* aeropuerto);
        ~Nodo();
        T obtener_dato();
        Nodo<T>* obtener_hijo_izquierdo();
        Nodo<T>* obtener_hijo_derecho();
        void asignar_dato(T dato);
        void asignar_aeropuerto(Aeropuerto* aeropuerto);
        void asignar_hijo_izquierdo(Nodo<T>* hijo_izquierdo);
        void asignar_hijo_derecho(Nodo<T>* hijo_derecho);
        void asignar_padre(Nodo<T>* padre);
        Nodo<T>* obtener_padre();
        Aeropuerto* obtener_aeropuerto();

        // PRE: --
        // POST: Remueve el hijo que sea igual al recibido por parámetro
        void remover_hijo(Nodo<T>* hijo);
};

template <class T>
Nodo<T>::Nodo(T clave, Aeropuerto* aeropuerto) {
    this->clave = clave;
    this->aeropuerto = aeropuerto;
    hijo_izquierdo = nullptr;
    hijo_derecho = nullptr;
}

template <class T>
Nodo<T>::~Nodo() {
    delete hijo_izquierdo;
    delete hijo_derecho;
    delete aeropuerto;
}

template <class T>
T Nodo<T>::obtener_dato() {
    return clave;
}

template <class T>
Nodo<T>* Nodo<T>::obtener_hijo_izquierdo() {
    return hijo_izquierdo;
}

template <class T>
Nodo<T>* Nodo<T>::obtener_hijo_derecho() {
    return hijo_derecho;
}

template <class T>
Nodo<T>* Nodo<T>::obtener_padre() {
    return padre;
}

template <class T>
void Nodo<T>::asignar_dato(T clave) {
    this->clave = clave;
}

template <class T>
void Nodo<T>::asignar_aeropuerto(Aeropuerto* aeropuerto) {
    this->aeropuerto = aeropuerto;
}

template <class T>
void Nodo<T>::asignar_hijo_izquierdo(Nodo* hijo_izquierdo) {
    this->hijo_izquierdo = hijo_izquierdo;
}

template <class T>
void Nodo<T>::asignar_hijo_derecho(Nodo* hijo_derecho) {
    this->hijo_derecho = hijo_derecho;
}

template <class T>
void Nodo<T>::asignar_padre(Nodo* padre) {
    this->padre = padre;
}

template <class T>
void Nodo<T>::remover_hijo(Nodo<T>* hijo) {
    if (hijo == hijo_izquierdo) {
        hijo_izquierdo = nullptr;
    } else {
        hijo_derecho = nullptr;
    }
}

#endif