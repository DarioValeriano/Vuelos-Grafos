//
// Created by luzacu on 20/02/24.
//

#include <iostream>
#include "aeropuerto.h"
#include "ABB.h"

using namespace std;

int main(){
    // Crear objeto ABB
    ABB<string> abb;

    // Leer aeropuertos desde el archivo y agregarlos al ABB
    ifstream archivo("aeropuertos.txt");

    string codigo_iata, nombre, ciudad, pais;
    double superficie;
    int cantidad_terminales, destinos_nacionales, destinos_internacionales;

    while (archivo >> codigo_iata >> nombre >> ciudad >> pais >> superficie
                   >> cantidad_terminales >> destinos_nacionales >> destinos_internacionales) {
        Aeropuerto* aeropuerto = new Aeropuerto(codigo_iata, nombre, ciudad, pais, superficie,
                                                cantidad_terminales, destinos_nacionales,
                                                destinos_internacionales);
        abb.insertar(codigo_iata, aeropuerto);
    }
    archivo.close();

    //cout << abb.esta_en_el_arbol("EZE") << endl;
    abb.post_orden();
    abb.opciones();
    cout << endl;
    //Aeropuerto aero;
    //aero.imprimir_matriz();

    return 0;
}
